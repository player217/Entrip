# Entrip v2 실행 안내

이 변경은 `b` 개발 브랜치를 기준으로 합니다. 기존 파란색·흰색 화면을 유지하며 예약, 작업 탭, 계좌·입출금·결재, 메신저, 직원 관리와 통계를 v2 API/DB에 연결합니다.

## Windows PC 한 대를 사내 서버로 사용하기

1. 호스트 PC의 로컬 폴더에 Windows LAN ZIP 전체를 풀고 **`run.bat`**을 더블클릭합니다. 처음에는 인터넷 연결과 Linux 컨테이너를 지원하는 Docker Desktop이 필요합니다. Docker가 없으면 실행기가 설치를 안내합니다. Windows가 재부팅을 요청하면 재부팅 후 같은 폴더의 `run.bat`을 다시 실행합니다.
2. 최초 빌드와 DB 초기화가 끝나면 호스트에서 로그인 화면이 열립니다. 콘솔에 나온 `.entrip-lan\first-login.txt`를 열어 회사·이메일·초기 비밀번호를 확인합니다. 호스트 관리자가 **설정 → 직원 추가**에서 직원별 계정을 만듭니다.
3. 직원에게 콘솔의 **같은 네트워크에서 접속** 주소와 직원 계정을 전달합니다. 예를 들어 호스트에 `http://192.168.0.25:3000`이 표시되면 직원은 같은 유선망이나 Wi-Fi에서 그 주소를 브라우저로 엽니다. 호스트 관리자 비밀번호와 `.entrip-lan` 폴더는 호스트에 보관합니다.

실행 창을 닫아도 서비스는 Docker에서 계속 동작합니다. 호스트 PC와 Docker가 켜져 있어야 다른 사용자도 접속할 수 있습니다. `run.bat status`로 서비스 상태를 확인하고 `run.bat stop`으로 중지합니다. 다시 `run.bat`을 실행하면 기존 직원·예약·메시지가 담긴 PostgreSQL 볼륨을 사용합니다. 폴더를 옮기거나 버전을 갱신할 때는 기존 `.entrip-lan` 설정과 Docker 볼륨을 함께 유지합니다.

다른 PC에서만 연결이 안 되면 호스트가 표시한 **현재 IP와 포트**, Windows 회사/개인 네트워크 프로필, 방화벽 권한, 게스트 Wi-Fi의 기기 간 격리 설정을 확인합니다. IP가 바뀌면 `run.bat`을 다시 실행하고 새 주소를 공유합니다. 기본 포트 3000이 사용 중이면 호스트의 `.entrip-lan\server.env`에서 `ENTRIP_LAN_PORT`를 변경하고 다시 실행합니다. 이 LAN 구성은 HTTP를 사용하므로 신뢰하는 내부망에서 사용합니다. 인터넷 공개용 TLS 구성은 [운영 안내](PRODUCTION_V2_RUNTIME.md)를 따릅니다.

## 개발용 로컬 실행

Node.js 22 이상, Corepack, PostgreSQL이 필요합니다. 프로젝트 루트에 `.env`를 만들고 접근 가능한 DB 주소를 지정합니다.

```dotenv
DATABASE_URL=postgresql://entrip:YOUR_PASSWORD@127.0.0.1:5432/entrip
```

Windows는 `START_ENTRIP.bat`, macOS/Linux는 `bash START_ENTRIP.sh`를 실행합니다. 패키지 설치 → v2 클라이언트 생성 → 보존형 DB 마이그레이션 → 빈 DB에만 데모 데이터 입력 → API 4002/웹 3000 실행 순서입니다. 웹 주소는 http://localhost:3000 입니다. 최초 화면에서 회사와 역할을 고릅니다.

데모 계정은 Entrip, J1, Startour, Happytravel의 관리자·매니저·직원이며 비밀번호는 `pass1234`입니다. 실제 업무 DB에 데모 계정을 배포하지 마세요. 기존 계정이 있으면 데모 입력을 건너뛰며 데이터를 삭제하지 않습니다. `RESET_DEMO_DATA=true`는 명시적인 개발용 전체 초기화 옵션입니다.

로컬 실행기의 JWT 서명 키는 `.env`에 없으면 실행마다 생성됩니다. 재시작 후 로그인이 풀리지 않게 하려면 `JWT_SECRET`, `JWT_REFRESH_SECRET`에 서로 다른 무작위 32자 이상의 값을 지정합니다. 운영은 [PRODUCTION_V2_RUNTIME.md](PRODUCTION_V2_RUNTIME.md)를 따릅니다.

## 주요 동작

- 월간·주간 캘린더와 목록에서 날짜나 예약을 선택합니다. 왼쪽 기본/고객 정보와 오른쪽 반복 여행 항목을 함께 저장합니다. 저장 후 인쇄와 변경 이력을 사용할 수 있습니다.
- Ctrl/Cmd+메뉴 클릭은 새 작업 탭을 엽니다. 탭별 입력과 편집 대상이 새로고침 후에도 유지됩니다. 회사나 사용자가 바뀌면 이전 작업 상태를 지웁니다.
- 계좌는 직원 계정과 별도입니다. 입출금을 등록하고 다른 관리자 또는 지정 결재자가 승인하면 잔액에 반영됩니다. 순차 결재는 지정된 순서를 따릅니다.
- 메신저에서 같은 회사 직원을 선택해 1:1 대화를 만들고 기존 방에 직원을 초대합니다. 메시지는 DB에 저장되며 실시간으로 전달됩니다.
- 관리자 설정에서 직원 추가·수정·비활성화·재활성화를 수행합니다.
- 항공편·환율은 실제 외부 서비스 설정이 필요합니다. 과거 스냅샷과 조회 실패를 구분해 표시합니다.

## 검증 및 제한

```bash
corepack pnpm install --frozen-lockfile
corepack pnpm run build
corepack pnpm exec jest --config jest.config.js --selectProjects @entrip/shared @entrip/ui @entrip/web --runInBand
```

API 테스트는 **별도의 `_test`로 끝나는 DB**에 `TEST_DATABASE_URL`을 설정하고 `bash scripts/test-db.prepare.sh`로 마이그레이션한 뒤 `corepack pnpm --filter @entrip/api test --runInBand`로 실행합니다. API 테스트는 해당 테스트 DB의 행을 삭제합니다.

실행 중인 앱의 실제 화면 검증 스크립트는 `scripts/verification/verify-*-ui.mjs`입니다. `BASE_URL`을 앱 주소로 지정합니다. 최종 실행 결과와 한계는 검증 문서를 참고하세요.

메일 OAuth/수신/발신, 자동화 실행, OCR·문서 연동은 미구현 상태를 명시합니다. 예약 출력은 브라우저 인쇄입니다. 운영 Docker·TLS 실행과 외부 제공자의 실시간 데이터 가용성은 별도 검증 대상입니다.
