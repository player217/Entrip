import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { logger } from '../lib/logger';

// 탭이 표시할 콘텐츠 타입을 정의
export type WorkspaceContentType = 'flow' | 'calendar' | 'monthlyCalendar' | 'monthlyList' | 'list' | 'empty';

// 탭 상태 타입들
export interface TabState {
  [key: string]: unknown;
}

export interface FormTabState extends TabState {
  formData?: Record<string, unknown>;
  isDirty?: boolean;
}

export interface FilterTabState extends TabState {
  filters?: Record<string, unknown>;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface CalendarTabState extends TabState {
  selectedDate?: string;
  viewType?: 'month' | 'week' | 'day';
  filters?: {
    companyCode?: string;
    status?: string[];
  };
}

export interface WorkspaceTab {
  key: string;
  label: string;
  icon: string;
  route: string; // 현재 URL
  history: string[]; // 탭 내부 이동 히스토리
  contentType?: WorkspaceContentType; // workspace 전용일 때만 사용
  closable?: boolean;
  // 탭별 상태 보존을 위한 새로운 필드들
  state?: TabState; // 탭별 상태 데이터 (폼 데이터, 필터 등)
  scrollPosition?: number; // 스크롤 위치
  isLoaded?: boolean; // 콘텐츠 로드 여부
}

interface WorkspaceState {
  ownerId: string | null;
  tabs: WorkspaceTab[];
  activeTabKey: string | null;
  sidebarCollapsed: boolean;
  addTab: (customTab?: Partial<WorkspaceTab>) => void;
  closeTab: (key: string) => void;
  setActiveTab: (key: string) => void;
  updateTab: (key: string, patch: Partial<WorkspaceTab>) => void;
  updateActiveTabContent: (contentType: WorkspaceContentType, label?: string, icon?: string) => void;
  updateTabState: (key: string, state: TabState) => void; // 탭 상태 업데이트
  toggleSidebar: () => void;
  bindOwner: (ownerId: string | null) => void;
  reorderTab: (key: string, targetIndex: number) => void;
}

export const useWorkspaceStore = create<WorkspaceState>()(
  persist(
    (set, get) => ({
  ownerId: null,
  tabs: [
    { 
      key: 'tab-1', 
      label: 'New Tab', 
      icon: 'ph:globe-bold', 
      route: '/',
      history: ['/'],
      contentType: 'empty',
      closable: true
    }
  ],
  activeTabKey: 'tab-1',
  sidebarCollapsed: false,

  addTab: (customTab?: Partial<WorkspaceTab>) => {
    try {
      // 탭 10개 제한
      if (get().tabs.length >= 10) {
        logger.warn('WorkspaceStore', 'Maximum tab limit reached (10)');
        return;
      }
      
      const newTabKey = customTab?.key || `tab-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      if (get().tabs.some(tab => tab.key === newTabKey)) return;
      const route = customTab?.route || '/';
      const newTab: WorkspaceTab = {
        key: newTabKey,
        label: customTab?.label || `Untitled-${get().tabs.length + 1}`,
        icon: customTab?.icon || 'ph:file-bold',
        route: route,
        history: [route],
        contentType: customTab?.contentType || 'empty',
        closable: customTab?.closable !== false,
        ...customTab
      };
      
      logger.info('WorkspaceStore', 'Adding new tab', { newTab });
      
      set((state) => ({
        tabs: [...state.tabs, newTab],
        activeTabKey: newTabKey
      }));
    } catch (error) {
      logger.error('WorkspaceStore', 'Failed to add tab', error);
    }
  },

  closeTab: (key: string) => {
    set((state) => {
      // closable이 false인 탭은 닫을 수 없음
      const tabToClose = state.tabs.find(tab => tab.key === key);
      if (tabToClose && tabToClose.closable === false) {
        return state;
      }
      
      const newTabs = state.tabs.filter(tab => tab.key !== key);
      
      // 마지막 탭을 닫으려 할 때 새 탭 생성
      if (newTabs.length === 0) {
        const newTab: WorkspaceTab = {
          key: `tab-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          label: '새 작업',
          icon: 'ph:globe-bold',
          route: '/workspace',
          history: ['/workspace'],
          contentType: 'empty',
          closable: true
        };
        return {
          tabs: [newTab],
          activeTabKey: newTab.key
        };
      }
      
      // Keep focus beside the closed pane.
      let newActiveKey = state.activeTabKey;
      if (state.activeTabKey === key) {
        const closedIndex = state.tabs.findIndex(tab => tab.key === key);
        newActiveKey = newTabs[Math.min(closedIndex, newTabs.length - 1)]?.key ?? null;
      }
      return {
        tabs: newTabs,
        activeTabKey: newActiveKey
      };
    });
  },

  setActiveTab: (key: string) => {
    if (get().tabs.some(tab => tab.key === key)) set({ activeTabKey: key });
  },

  updateTab: (key: string, patch: Partial<WorkspaceTab>) => {
    set((state) => ({
      tabs: state.tabs.map(tab => 
        tab.key === key 
          ? { ...tab, ...patch }
          : tab
      )
    }));
  },

  updateActiveTabContent: (contentType: WorkspaceContentType, label?: string, icon?: string) => {
    set((state) => {
      const activeTab = state.tabs.find(tab => tab.key === state.activeTabKey);
      if (!activeTab) return state;

      const updatedTabs = state.tabs.map(tab => {
        if (tab.key === state.activeTabKey) {
          return {
            ...tab,
            contentType,
            label: label || getDefaultLabel(contentType),
            icon: icon || getDefaultIcon(contentType)
          };
        }
        return tab;
      });

      return { tabs: updatedTabs };
    });
  },

  updateTabState: (key: string, state: TabState) => {
    set((store) => ({
      tabs: store.tabs.map(tab => 
        tab.key === key 
          ? { ...tab, state: { ...tab.state, ...state } }
          : tab
      )
    }));
  },

  toggleSidebar: () => {
    set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed }));
  },

  bindOwner: (ownerId: string | null) => {
    if (get().ownerId === ownerId) return;
    const key = `tab-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    set({ ownerId, tabs: [{ key, label: '대시보드', icon: 'ph:layout-bold', route: '/', history: ['/'], closable: true }], activeTabKey: key });
  },

  reorderTab: (key: string, targetIndex: number) => {
    set(state => {
      const sourceIndex = state.tabs.findIndex(tab => tab.key === key);
      if (sourceIndex < 0 || !Number.isInteger(targetIndex)) return state;
      const destination = Math.max(0, Math.min(targetIndex, state.tabs.length - 1));
      if (sourceIndex === destination) return state;
      const tabs = [...state.tabs];
      const [tab] = tabs.splice(sourceIndex, 1);
      if (!tab) return state;
      tabs.splice(destination, 0, tab);
      return { tabs };
    });
  }
    }),
    {
      name: 'workspace-storage', // localStorage key
      partialize: (state) => ({ ownerId: state.ownerId, tabs: state.tabs, activeTabKey: state.activeTabKey, sidebarCollapsed: state.sidebarCollapsed }),
    }
  )
);

// 콘텐츠 타입별 기본 라벨
function getDefaultLabel(contentType: WorkspaceContentType): string {
  const labels = {
    flow: 'Flow Editor',
    calendar: '주별 캘린더',
    monthlyCalendar: '월별 캘린더',
    monthlyList: '월별 목록',
    list: '예약 목록',
    empty: 'New Tab'
  };
  return labels[contentType] || 'New Tab';
}

// 콘텐츠 타입별 기본 아이콘
function getDefaultIcon(contentType: WorkspaceContentType): string {
  const icons = {
    flow: 'ph:flow-arrow-bold',
    calendar: 'ph:calendar-bold',
    monthlyCalendar: 'ph:calendar-blank-bold',
    monthlyList: 'ph:list-checks-bold',
    list: 'ph:list-bold',
    empty: 'ph:globe-bold'
  };
  return icons[contentType] || 'ph:globe-bold';
}
