'use client'

import { useId, useMemo, useState } from 'react'
import { format, isToday } from 'date-fns'
import { ko } from 'date-fns/locale'
import { useBookings } from '../../../hooks/useBookings'
import type { Booking } from '@entrip/shared'
import { dateKey, bookingCurrency, money } from '../../../lib/bookingAnalytics'

interface DepartureTeam {
  id: string
  teamName: string
  destination: string
  paxCount: number
  departureTime: string
  manager: string
  status: 'confirmed' | 'checking' | 'delayed'
}

interface NewBookingToday {
  id: string
  teamName: string
  destination: string
  customerName: string
  totalPrice: number
  currency: string
  createdTime: string
}

export function TodayBookingsSection() {
  const { bookings: apiBookings, isLoading, isError } = useBookings()
  const [showAllDepartures, setShowAllDepartures] = useState(false)
  const [showAllNewBookings, setShowAllNewBookings] = useState(false)
  const departuresId = useId()
  const newBookingsId = useId()

  const todayData = useMemo(() => {
    if (!apiBookings || apiBookings.length === 0) {
      return {
        departures: [],
        newBookings: [],
        pendingCount: 0
      }
    }

    const today = new Date()
    const todayStr = format(today, 'yyyy-MM-dd')

    // 오늘 출발하는 팀들
    const departures: DepartureTeam[] = apiBookings
      .filter((booking: Booking) => dateKey(booking.startDate) === todayStr && booking.status !== 'CANCELLED')
      .map((booking: Booking) => ({
        id: booking.id,
        teamName: booking.teamName,
        destination: booking.destination,
        paxCount: booking.paxCount,
        departureTime: '출발 시각 미제공',
        manager: booking.managerName || booking.coordinator || booking.user?.name || '미정',
        status: booking.status === 'CONFIRMED' ? 'confirmed' : 'checking'
      }))

    // 오늘 등록된 신규 예약 (createdAt 기준)
    const newBookings: NewBookingToday[] = apiBookings
      .filter((booking: Booking) => {
        const createdDate = new Date(booking.createdAt)
        return isToday(createdDate)
      })
      .map((booking: Booking) => ({
        id: booking.id,
        teamName: booking.teamName,
        destination: booking.destination,
        customerName: booking.customerName,
        totalPrice: booking.totalPrice,
        currency: bookingCurrency(booking),
        createdTime: format(new Date(booking.createdAt), 'HH:mm')
      }))

    // 대기 중인 예약 수
    const pendingCount = apiBookings.filter(
      (booking: Booking) => booking.status === 'PENDING'
    ).length

    return {
      departures,
      newBookings,
      pendingCount
    }
  }, [apiBookings])

  if (isError) return <p role="alert" className="p-6 text-red-700">오늘의 예약을 불러오지 못했습니다.</p>

  if (isLoading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="space-y-3">
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded w-5/6"></div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900">오늘의 예약 현황</h3>
        <span className="text-sm text-gray-500">
          {format(new Date(), 'M월 d일', { locale: ko })}
        </span>
      </div>

      <div className="space-y-6">
        {/* 오늘 출발하는 팀들 */}
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
            <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
            오늘 출발 ({todayData.departures.length}팀)
          </h4>
          {todayData.departures.length > 0 ? (
            <div id={departuresId} className="space-y-2">
              {(showAllDepartures ? todayData.departures : todayData.departures.slice(0, 3)).map((team) => (
                <div key={team.id} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${
                      team.status === 'confirmed' ? 'bg-green-500' : 'bg-yellow-500'
                    }`}></div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">{team.teamName}</p>
                      <p className="text-xs text-gray-600">{team.destination} · {team.paxCount}명</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-700">{team.departureTime}</p>
                    <p className="text-xs text-gray-500">{team.manager}</p>
                  </div>
                </div>
              ))}
              {!showAllDepartures && todayData.departures.length > 3 && <p className="entrip-print-only dashboard-preview-count">전체 {todayData.departures.length}건 중 화면에 표시된 3건</p>}
              {todayData.departures.length > 3 && (
                <button type="button" aria-expanded={showAllDepartures} aria-controls={departuresId}
                  onClick={() => setShowAllDepartures(value => !value)}
                  className="w-full rounded py-2 text-center text-xs text-blue-700 hover:bg-blue-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-blue-500">
                  {showAllDepartures ? '오늘 출발 접기' : `+${todayData.departures.length - 3}개 팀 더보기`}
                </button>
              )}
            </div>
          ) : (
            <p className="text-sm text-gray-500 py-3">오늘 출발하는 팀이 없습니다.</p>
          )}
        </div>

        {/* 오늘 등록된 신규 예약 */}
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
            <span className="w-2 h-2 bg-green-500 rounded-full"></span>
            신규 예약 ({todayData.newBookings.length}건)
          </h4>
          {todayData.newBookings.length > 0 ? (
            <div id={newBookingsId} className="space-y-2">
              {(showAllNewBookings ? todayData.newBookings : todayData.newBookings.slice(0, 3)).map((booking) => (
                <div key={booking.id} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{booking.teamName}</p>
                    <p className="text-xs text-gray-600">{booking.customerName} · {booking.destination}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-700">{money(booking.totalPrice, booking.currency)}</p>
                    <p className="text-xs text-gray-500">{booking.createdTime}</p>
                  </div>
                </div>
              ))}
              {!showAllNewBookings && todayData.newBookings.length > 3 && <p className="entrip-print-only dashboard-preview-count">전체 {todayData.newBookings.length}건 중 화면에 표시된 3건</p>}
              {todayData.newBookings.length > 3 && (
                <button type="button" aria-expanded={showAllNewBookings} aria-controls={newBookingsId}
                  onClick={() => setShowAllNewBookings(value => !value)}
                  className="w-full rounded py-2 text-center text-xs text-blue-700 hover:bg-green-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-blue-500">
                  {showAllNewBookings ? '신규 예약 접기' : `+${todayData.newBookings.length - 3}건 더보기`}
                </button>
              )}
            </div>
          ) : (
            <p className="text-sm text-gray-500 py-3">오늘 등록된 신규 예약이 없습니다.</p>
          )}
        </div>

        {/* 처리 대기 중인 업무 */}
        {todayData.pendingCount > 0 && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-yellow-500 rounded-full"></span>
              <h4 className="text-sm font-medium text-yellow-800">
                처리 대기 중 ({todayData.pendingCount}건)
              </h4>
            </div>
            <p className="text-sm text-yellow-700 mt-1">
              확정 대기 중인 예약이 {todayData.pendingCount}건 있습니다.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
